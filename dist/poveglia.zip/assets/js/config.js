/**
* Config JS file for Poveglia
*/

var config = {
    'share-selected-text': true,
    'load-more': true,
    'infinite-scroll': false,
    'infinite-scroll-step': 1,
    'disqus-shortname': 'hauntedthemes-demo',
    'content-api-host': 'https://intrepidpixel.org',
    'content-api-key': '54e0481aa8fdef7f4c17578dbc',
    'content-api-url': 'https://intrepidpixel.org',
};